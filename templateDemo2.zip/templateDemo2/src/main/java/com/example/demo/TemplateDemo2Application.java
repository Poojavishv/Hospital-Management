package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(TemplateDemo2Application.class, args);
	}

}
